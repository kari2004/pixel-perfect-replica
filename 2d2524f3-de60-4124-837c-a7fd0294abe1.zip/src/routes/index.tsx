import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ParticleCanvas, CursorAura, ScrollBar, Preloader } from "@/components/sanctuary/fx";
import { Brand, Hero, Oracle, Chapters, Reader, type Pos } from "@/components/sanctuary/sections";
import { Dock, toSaved, type Saved } from "@/components/sanctuary/dock";
import type { Verse } from "@/data/gita";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "G1TA — The Eternal Song of the Divine | Bhagavad Gita Reader" },
      { name: "description", content: "A digital sanctuary for the Bhagavad Gita: all 18 chapters, Sanskrit with word-by-word meaning, modern reflections and a 432Hz meditation drone." },
      { property: "og:title", content: "G1TA — The Eternal Song of the Divine" },
      { property: "og:description", content: "When the mind is at war, enter the eternal dialogue. Read the Bhagavad Gita in a luxurious, contemplative sanctuary." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const LINKS = [["oracle", "Oracle"], ["chapters", "Chapters"], ["reader", "Sanctuary"]] as const;

function Index() {
  const [intro, setIntro] = useState(true);
  const [pos, setPos] = useState<Pos>({ ch: 2, v: 47 });
  const [zen, setZen] = useState(false);
  const [light, setLight] = useState(false);
  const [saved, setSavedState] = useState<Saved[]>([]);

  useEffect(() => {
    try { setSavedState(JSON.parse(localStorage.getItem("g1ta-saved") || "[]")); } catch { /* empty */ }
    setLight(localStorage.getItem("g1ta-theme") === "light");
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle("parchment", light);
    localStorage.setItem("g1ta-theme", light ? "light" : "dark");
  }, [light]);

  const setSaved = (s: Saved[]) => { setSavedState(s); localStorage.setItem("g1ta-saved", JSON.stringify(s)); };
  const toggleSave = (v: Verse) => {
    const k = `${v.ch}.${v.v}`;
    setSaved(saved.some((s) => s.key === k) ? saved.filter((s) => s.key !== k) : [toSaved(v), ...saved]);
  };
  const open = useCallback((p: Pos) => {
    setPos(p);
    requestAnimationFrame(() => document.getElementById("reader")?.scrollIntoView({ behavior: "smooth" }));
  }, []);
  const done = useCallback(() => setIntro(false), []);

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <AnimatePresence>{intro && <Preloader onDone={done} />}</AnimatePresence>
      <ParticleCanvas />
      <CursorAura />
      <ScrollBar />

      <motion.header animate={{ opacity: zen ? 0 : 1, y: zen ? -20 : 0 }} className="fixed inset-x-0 top-0 z-40 px-4 pb-4 pt-3 md:px-10 md:py-5" style={{ pointerEvents: zen ? "none" : "auto", background: "linear-gradient(to bottom, var(--background) 30%, transparent)" }}>
        <div className="flex items-center justify-between gap-3">
          <Brand />
          <nav className="text-muted-foreground hidden gap-8 text-[11px] uppercase tracking-[0.3em] md:flex">
            {LINKS.map(([id, l]) => <a key={id} href={`#${id}`} className="hover:text-gold transition-colors">{l}</a>)}
          </nav>
          <nav aria-label="Sections" className="glass flex items-center rounded-full p-1 md:hidden">
            {LINKS.map(([id, l]) => (
              <a key={id} href={`#${id}`} className="text-muted-foreground hover:text-gold active:text-gold flex min-h-11 min-w-11 items-center justify-center rounded-full px-2.5 text-[9px] uppercase tracking-[0.18em] transition-colors">{l}</a>
            ))}
          </nav>
        </div>
      </motion.header>

      <main className="relative z-10">
        {!zen && <Hero onBegin={() => open({ ch: 1, v: 1 })} onOracle={() => document.getElementById("oracle")?.scrollIntoView({ behavior: "smooth" })} />}
        {!zen && <Oracle onOpen={open} />}
        {!zen && <Chapters onOpen={open} />}
        <Reader pos={pos} setPos={setPos} zen={zen} isSaved={(k) => saved.some((s) => s.key === k)} toggleSave={toggleSave} />
        {!zen && (
          <footer className="text-muted-foreground px-6 pb-36 pt-16 text-center">
            <p className="font-deva text-gold text-xl">ॐ तत् सत्</p>
            <p className="mt-3 text-[10px] uppercase tracking-[0.4em]">G1TA.COM · The Eternal Song of the Divine</p>
          </footer>
        )}
      </main>

      <Dock zen={zen} setZen={setZen} light={light} setLight={setLight} saved={saved} setSaved={setSaved} onGo={open} />
    </div>
  );
}
